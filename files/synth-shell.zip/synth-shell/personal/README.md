Feel free to pull request your config files to share them here :)
